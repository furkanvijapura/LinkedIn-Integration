//
//  ObjectiveCHeader.h
//  Example
//
//  Created by Li Jiantang on 19/11/2015.
//  Copyright © 2015 Carma. All rights reserved.
//

#ifndef ObjectiveCHeader_h
#define ObjectiveCHeader_h

#import <LinkedinSwift/LSHeader.h> // this will use both for POD and import framework.

#endif /* ObjectiveCHeader_h */
