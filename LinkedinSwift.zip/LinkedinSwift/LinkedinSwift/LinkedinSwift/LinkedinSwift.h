//
//  LinkedinSwift.h
//  LinkedinSwift
//
//  Created by Li Jiantang on 17/11/2015.
//  Copyright © 2015 Carma. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LinkedinSwift.
FOUNDATION_EXPORT double LinkedinSwiftVersionNumber;

//! Project version string for LinkedinSwift.
FOUNDATION_EXPORT const unsigned char LinkedinSwiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LinkedinSwift/PublicHeader.h>



#import <LinkedinSwift/LSHeader.h>
