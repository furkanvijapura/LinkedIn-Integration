//
//  NativeAppInstalledToggleChecker.m
//  LinkedinSwift
//
//  Created by Li Jiantang on 29/08/2016.
//  Copyright © 2016 Carma. All rights reserved.
//

#import "NativeAppInstalledToggleChecker.h"

@implementation NativeAppInstalledToggleChecker
@synthesize installed;


- (BOOL)isLinkedinAppInstalled {
    return installed;
}

@end
